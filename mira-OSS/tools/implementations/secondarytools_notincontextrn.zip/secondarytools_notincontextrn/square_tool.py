"""
Integration tool for Square's MCP server.

This tool provides a thin proxy between MIRA and Square's Model Context Protocol
server, exposing common Square capabilities like managing appointments and
customers. It uses the shared MCP client (utils.mcp_client) to manage
user-scoped connections with retry and credential support.
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import uuid
from typing import Any, Callable, Coroutine, Dict, Optional, List
from urllib.parse import urlencode

from pydantic import BaseModel, Field

from config import config
from tools.registry import registry
from tools.repo import Tool
from auth.user_credentials import UserCredentialService
try:
    from utils import mcp_client
    from utils.mcp_client import (
        MCPAuthenticationError,
        MCPConnectionError,
        MCPError,
        MCPToolNotFoundError,
    )
    _MCP_IMPORT_ERROR: Optional[Exception] = None
except ModuleNotFoundError as exc:  # pragma: no cover - env specific
    mcp_client = None  # type: ignore
    MCPAuthenticationError = MCPConnectionError = MCPError = MCPToolNotFoundError = Exception  # type: ignore
    _MCP_IMPORT_ERROR = exc


# Conservative defaults – override via configuration if server tool names differ
DEFAULT_ALIAS_MAP: Dict[str, str] = {
    "list_appointments": "appointments.listBookings",
    "get_appointment": "appointments.retrieveBooking",
    "create_appointment": "appointments.createBooking",
    "update_appointment": "appointments.updateBooking",
    "cancel_appointment": "appointments.cancelBooking",
    "list_customer_appointments": "appointments.searchBookings",
    "list_customers": "customers.listCustomers",
    "get_customer": "customers.retrieveCustomer",
    "create_customer": "customers.createCustomer",
    "update_customer": "customers.updateCustomer",
    "delete_customer": "customers.deleteCustomer",
    "search_customers": "customers.searchCustomers",
    "list_catalog": "catalog.listCatalog",
    "retrieve_catalog_object": "catalog.retrieveCatalogObject",
}

OAUTH_AUTHORIZE_URLS = {
    "production": "https://connect.squareup.com/oauth2/authorize",
    "sandbox": "https://connect.squareupsandbox.com/oauth2/authorize",
}

OAUTH_CONFIG_CREDENTIAL_PREFIX = "square_oauth_config_"
OAUTH_STATE_CREDENTIAL_PREFIX = "square_oauth_state_"


class SquareToolConfig(BaseModel):
    """Configuration options for the Square MCP tool."""

    enabled: bool = Field(
        default=True,
        description="Whether this tool is enabled by default",
    )
    server_name: str = Field(
        default="square",
        description="Identifier used for the Square MCP server in the shared connection pool",
    )
    server_url: str = Field(
        default="https://mcp.squareup.com/sse",
        description="Square MCP server URL (SSE endpoint)",
    )
    max_retries: int = Field(
        default=3,
        description="Retry attempts for transient MCP failures",
    )
    alias_overrides: Dict[str, str] = Field(
        default_factory=dict,
        description="Optional mapping of friendly operation names to MCP tool IDs",
    )
    transport: str = Field(
        default="sse",
        description="Transport to use when connecting to the Square MCP server (sse or stdio)",
    )
    environment: str = Field(
        default="production",
        description="Target Square environment: 'production' or 'sandbox'",
    )
    client_id: Optional[str] = Field(
        default=None,
        description="Square OAuth application ID (required to generate authorization URLs)",
    )
    client_secret: Optional[str] = Field(
        default=None,
        description="Square OAuth application secret (stored securely for token exchange).",
    )
    redirect_uri: Optional[str] = Field(
        default=None,
        description="Redirect URI registered with Square OAuth application",
    )
    scopes: List[str] = Field(
        default_factory=list,
        description="List of Square OAuth scopes to request when generating the authorization URL",
    )
    oauth_optional_params: Dict[str, str] = Field(
        default_factory=dict,
        description="Additional query parameters to append to the Square authorization URL",
    )


registry.register("square_tool", SquareToolConfig)


class SquareTool(Tool):
    """Proxies Square MCP operations for appointments, customers, and catalog management."""

    name = "square_tool"
    description = (
        "Access Square's platform via its MCP server. Supports listing available tools, "
        "calling specific Square MCP tools, inspecting resources, and managing OAuth tokens."
    )
    simple_description = (
        "Interacts with Square's MCP server so MIRA can manage appointments, customers, and other Square data."
        " Requires configuring Square OAuth credentials (client ID, secret, redirect URI, scopes) via"
        " the configure_oauth operation before generating authorization links or setting access tokens."
    )
    usage_examples = [
        {
            "input": {
                "operation": "list_tools"
            },
            "output": {
                "success": True,
                "tools": [
                    {"name": "customers.listCustomers", "description": "List Square customers"}
                ]
            }
        },
        {
            "input": {
                "operation": "call_tool",
                "alias": "update_customer",
                "arguments": {
                    "customer_id": "J1H23K9PQM6Z4",
                    "given_name": "Mira",
                    "family_name": "Assistant"
                }
            },
            "output": {
                "success": True,
                "tool": "customers.updateCustomer",
                "result": {"outputs": ["…"]}
            }
        },
        {
            "input": {
                "operation": "generate_authorization_url"
            },
            "output": {
                "success": True,
                "authorization_url": "https://connect.squareup.com/oauth2/authorize?client_id=...",
                "environment": "production",
                "scopes": ["APPOINTMENTS_READ", "CUSTOMERS_WRITE"],
                "auth_urls": ["https://connect.squareup.com/oauth2/authorize?client_id=..."]
            }
        },
        {
            "input": {
                "operation": "configure_oauth",
                "environment": "sandbox",
                "client_id": "sandbox-sq0idb-XXXX",
                "client_secret": "sandbox-sq0csb-YYYY",
                "redirect_uri": "http://localhost:1993",
                "scopes": ["APPOINTMENTS_READ", "APPOINTMENTS_WRITE", "CUSTOMERS_READ", "CUSTOMERS_WRITE"]
            },
            "output": {
                "success": True,
                "message": "Square OAuth configuration updated",
                "environment": "sandbox",
                "authorization_url": "https://connect.squareupsandbox.com/oauth2/authorize?client_id=...",
                "auth_urls": ["https://connect.squareupsandbox.com/oauth2/authorize?client_id=..."],
                "settings": {
                    "client_id": "sandbox-sq0idb-XXXX",
                    "redirect_uri": "http://localhost:1993",
                    "scopes": ["APPOINTMENTS_READ", "APPOINTMENTS_WRITE", "CUSTOMERS_READ", "CUSTOMERS_WRITE"]
                }
            }
        }
    ]
    anthropic_schema = {
        "name": "square_tool",
        "description": description,
        "input_schema": {
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": [
                            "list_tools",
                            "call_tool",
                            "list_resources",
                            "get_resource",
                            "describe_aliases",
                            "set_token",
                            "clear_token",
                            "token_status",
                            "generate_authorization_url",
                            "configure_oauth",
                        ],
                        "description": "High-level operation to execute against the Square MCP server",
                    },
                    "tool_name": {
                        "type": "string",
                        "description": "Exact MCP tool name to call (e.g., 'customers.updateCustomer')",
                    },
                    "alias": {
                        "type": "string",
                        "description": "Friendly alias resolved via configuration (e.g., 'update_customer')",
                    },
                    "arguments": {
                        "type": "object",
                        "description": "Arguments passed to the selected Square MCP tool",
                    },
                    "resource_uri": {
                        "type": "string",
                        "description": "URI of a Square MCP resource to retrieve",
                    },
                    "refresh": {
                        "type": "boolean",
                        "description": "Set true to bypass cached tool/resource metadata",
                    },
                    "token": {
                        "type": "string",
                        "description": "Square OAuth access token obtained after calling the Square token endpoint",
                    },
                    "authorization_code": {
                        "type": "string",
                        "description": "Authorization code received from Square redirect (for future token exchange support)",
                    },
                    "environment": {
                        "type": "string",
                        "description": "Square environment ('production' or 'sandbox') for configure_oauth and authorization URL generation",
                    },
                    "client_id": {
                        "type": "string",
                        "description": "Square OAuth application ID provided in the Developer Dashboard",
                    },
                    "client_secret": {
                        "type": "string",
                        "description": "Square OAuth application secret (stored securely; never returned in responses)",
                    },
                    "redirect_uri": {
                        "type": "string",
                        "description": "Redirect URI registered with Square OAuth settings (HTTPS in production)",
                    },
                    "scopes": {
                        "oneOf": [
                            {"type": "array", "items": {"type": "string"}},
                            {"type": "string"}
                        ],
                        "description": "Scopes to request during OAuth authorization (array or space/comma-delimited string)",
                    },
                    "oauth_optional_params": {
                        "type": "object",
                        "description": "Additional query parameters to append to the Square authorization URL (for advanced Square OAuth options)",
                    },
                },
                "required": ["operation"],
                "additionalProperties": False,
            },
        }

    def __init__(self) -> None:
        super().__init__()
        if _MCP_IMPORT_ERROR is not None:
            raise RuntimeError(
                "Square MCP tool unavailable: missing optional dependency 'mcp'. "
                "Install it (e.g., `pip install mcp`) to enable Square integration."
            ) from _MCP_IMPORT_ERROR
        self.logger = logging.getLogger(__name__)
        self._config: SquareToolConfig = config.square_tool
        self._server_name = self._config.server_name
        self._server_url = self._config.server_url
        self._transport = self._config.transport
        self._max_retries = self._config.max_retries
        self._alias_map = {**DEFAULT_ALIAS_MAP, **(self._config.alias_overrides or {})}
        self._credential_service = UserCredentialService(self.user_id)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def run(self, operation: str, **kwargs: Any) -> Dict[str, Any]:
        """Execute a Square MCP operation."""
        if not operation:
            raise ValueError("Operation is required")

        op = operation.strip().lower()

        if op == "list_tools":
            refresh = bool(kwargs.get("refresh", False))
            return self._safe_execute(lambda: self._list_tools_async(refresh=refresh))

        if op == "list_resources":
            refresh = bool(kwargs.get("refresh", False))
            return self._safe_execute(lambda: self._list_resources_async(refresh=refresh))

        if op == "get_resource":
            resource_uri = kwargs.get("resource_uri")
            if not resource_uri or not isinstance(resource_uri, str):
                raise ValueError("resource_uri must be provided as a string")
            return self._safe_execute(lambda: self._get_resource_async(resource_uri))

        if op == "call_tool":
            tool_name = kwargs.get("tool_name")
            alias = kwargs.get("alias") or kwargs.get("action")
            arguments = self._coerce_arguments(kwargs.get("arguments"))
            resolved, used_alias = self._resolve_tool_identifier(tool_name, alias)
            return self._safe_execute(
                lambda: self._call_tool_async(resolved, arguments or {}),
                extra_context={"resolved_tool": resolved, "used_alias": used_alias, "arguments": arguments or {}},
            )

        if op == "describe_aliases":
            return {
                "success": True,
                "aliases": self._alias_map,
            }

        if op == "set_token":
            token = kwargs.get("token")
            if not token or not isinstance(token, str):
                try:
                    auth_context = self._build_authorization_context()
                    return {
                        "success": False,
                        "message": "No token provided. Use the authorization URL to complete Square OAuth, then call set_token with the returned access token.",
                        "auth_urls": [auth_context["authorization_url"]],
                        **auth_context,
                    }
                except ValueError as exc:
                    return {
                        "success": False,
                        "error": str(exc),
                        "code": "CONFIGURATION_REQUIRED",
                    }

            self._credential_service.store_credential(
                self.user_id, "oauth_token", self._server_name, token.strip()
            )
            return {
                "success": True,
                "message": "Square OAuth token stored",
            }

        if op == "generate_authorization_url":
            try:
                auth_context = self._build_authorization_context()
                return {
                    "success": True,
                    "auth_urls": [auth_context["authorization_url"]],
                    **auth_context,
                }
            except ValueError as exc:
                return {
                    "success": False,
                    "error": str(exc),
                    "code": "CONFIGURATION_REQUIRED",
                }

        if op == "configure_oauth":
            environment = (kwargs.get("environment") or self._config.environment or "production").lower()
            updates: Dict[str, Any] = {}

            for field in ("client_id", "client_secret", "redirect_uri"):
                value = kwargs.get(field)
                if value is not None:
                    if not isinstance(value, str):
                        raise ValueError(f"{field} must be a string")
                    updates[field] = value.strip()

            if "scopes" in kwargs:
                updates["scopes"] = self._parse_scopes(kwargs.get("scopes"))

            if "oauth_optional_params" in kwargs:
                updates["oauth_optional_params"] = self._parse_optional_params(
                    kwargs.get("oauth_optional_params")
                )

            if not updates:
                return {
                    "success": False,
                    "error": "No configuration values provided. Specify client_id, client_secret, redirect_uri, scopes, or oauth_optional_params.",
                    "code": "CONFIGURATION_REQUIRED",
                }

            self._store_oauth_settings(environment, updates)

            try:
                auth_context = self._build_authorization_context(environment=environment)
            except ValueError as exc:
                return {
                    "success": True,
                    "message": "OAuth configuration updated, but additional fields are required before generating an authorization URL.",
                    "environment": environment,
                    "details": str(exc),
                }

            return {
                "success": True,
                "message": "Square OAuth configuration updated",
                "environment": environment,
                "auth_urls": [auth_context["authorization_url"]],
                **auth_context,
            }

        if op == "clear_token":
            removed = self._credential_service.delete_credential(
                self.user_id, "oauth_token", self._server_name
            )
            return {
                "success": removed,
                "message": "Square OAuth token cleared" if removed else "No stored token",
            }

        if op == "token_status":
            token = self._credential_service.get_credential(
                self.user_id, "oauth_token", self._server_name
            )
            return {
                "success": True,
                "has_token": bool(token),
            }

        raise ValueError(
            "Unsupported operation. Valid options: list_tools, call_tool, list_resources, "
            "get_resource, describe_aliases, set_token, configure_oauth, clear_token, token_status"
        )

    # ------------------------------------------------------------------
    # MCP helpers (async)
    # ------------------------------------------------------------------
    async def _list_tools_async(self, refresh: bool) -> Dict[str, Any]:
        async with mcp_client.create_session(
            self._server_name,
            self._server_url,
            transport=self._transport,
            max_retries=self._max_retries,
        ) as connection:
            tools = await connection.list_tools(use_cache=not refresh)

        return {
            "success": True,
            "tools": [self._serialize(tool) for tool in tools],
            "cached": not refresh,
        }

    async def _list_resources_async(self, refresh: bool) -> Dict[str, Any]:
        async with mcp_client.create_session(
            self._server_name,
            self._server_url,
            transport=self._transport,
            max_retries=self._max_retries,
        ) as connection:
            resources = await connection.list_resources(use_cache=not refresh)

        return {
            "success": True,
            "resources": [self._serialize(resource) for resource in resources],
            "cached": not refresh,
        }

    async def _get_resource_async(self, resource_uri: str) -> Dict[str, Any]:
        async with mcp_client.create_session(
            self._server_name,
            self._server_url,
            transport=self._transport,
            max_retries=self._max_retries,
        ) as connection:
            payload = await connection.get_resource(resource_uri)

        return {
            "success": True,
            "resource": resource_uri,
            "payload": self._serialize(payload),
        }

    async def _call_tool_async(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        async with mcp_client.create_session(
            self._server_name,
            self._server_url,
            transport=self._transport,
            max_retries=self._max_retries,
        ) as connection:
            result = await connection.call_tool(tool_name, arguments)

        return {
            "success": True,
            "tool": tool_name,
            "result": self._serialize(result),
        }

    # ------------------------------------------------------------------
    # Utility helpers
    # ------------------------------------------------------------------
    def _resolve_tool_identifier(
        self,
        explicit_name: Optional[str],
        alias: Optional[str],
    ) -> tuple[str, Optional[str]]:
        if explicit_name and not isinstance(explicit_name, str):
            raise ValueError("tool_name must be a string if provided")
        if alias and not isinstance(alias, str):
            raise ValueError("alias must be a string if provided")

        if explicit_name:
            return explicit_name, None

        if not alias:
            raise ValueError("Provide either tool_name or alias for call_tool operation")

        resolved = self._alias_map.get(alias)
        if not resolved:
            raise ValueError(f"Unknown Square alias '{alias}'. Use describe_aliases to inspect available options")
        return resolved, alias

    def _coerce_arguments(self, raw: Any) -> Optional[Dict[str, Any]]:
        if raw is None:
            return None

        if isinstance(raw, dict):
            return raw

        if isinstance(raw, str):
            raw = raw.strip()
            if not raw:
                return None
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Could not parse arguments JSON: {exc}") from exc
            if not isinstance(parsed, dict):
                raise ValueError("Arguments JSON must decode to an object")
            return parsed

        raise ValueError("arguments must be provided as a dict or JSON string")

    def _safe_execute(
        self,
        coro_factory: Callable[[], Coroutine[Any, Any, Dict[str, Any]]],
        extra_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        try:
            return self._run_coroutine(coro_factory)
        except MCPToolNotFoundError as exc:
            self.logger.warning("Requested Square tool not found: %s", exc)
            return {
                "success": False,
                "error": str(exc),
                "code": "TOOL_NOT_FOUND",
                **(extra_context or {}),
            }
        except MCPAuthenticationError as exc:
            self.logger.warning("Square authentication error: %s", exc)
            server_message = str(exc)
            auth_urls = self._extract_urls(server_message)
            auth_urls_from_exc = self._extract_urls_from_exception(exc)
            if auth_urls_from_exc:
                auth_urls = list({*(auth_urls or []), *auth_urls_from_exc})
            response: Dict[str, Any] = {
                "success": False,
                "error": "Authentication with Square failed or token is missing",
                "code": "AUTHENTICATION_ERROR",
                "server_message": server_message,
                **(extra_context or {}),
            }
            if auth_urls:
                response["auth_urls"] = auth_urls
            return response
        except MCPConnectionError as exc:
            self.logger.error("Square MCP connection error: %s", exc)
            return {
                "success": False,
                "error": "Unable to contact Square MCP server",
                "code": "CONNECTION_ERROR",
                **(extra_context or {}),
            }
        except MCPError as exc:
            self.logger.error("Square MCP error: %s", exc)
            return {
                "success": False,
                "error": str(exc),
                "code": "MCP_ERROR",
                **(extra_context or {}),
            }

    def _run_coroutine(self, coro_factory: Callable[[], Coroutine[Any, Any, Dict[str, Any]]]) -> Dict[str, Any]:
        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None

        if running_loop and running_loop.is_running():
            result_container: Dict[str, Any] = {}
            error_container: Dict[str, BaseException] = {}

            def _runner() -> None:
                loop = asyncio.new_event_loop()
                try:
                    asyncio.set_event_loop(loop)
                    result_container["value"] = loop.run_until_complete(coro_factory())
                except BaseException as exc:  # propagate coroutine errors
                    error_container["error"] = exc
                finally:
                    loop.run_until_complete(loop.shutdown_asyncgens())
                    loop.close()

            thread = threading.Thread(target=_runner, daemon=True)
            thread.start()
            thread.join()

            if error_container:
                raise error_container["error"]
            return result_container.get("value", {})

        return asyncio.run(coro_factory())

    def _serialize(self, value: Any) -> Any:
        if value is None:
            return None
        if hasattr(value, "model_dump"):
            try:
                return value.model_dump()
            except Exception:
                pass
        if isinstance(value, (list, tuple)):
            return [self._serialize(item) for item in value]
        if isinstance(value, dict):
            return {key: self._serialize(val) for key, val in value.items()}
        return value

    def _extract_urls(self, text: str) -> Optional[list[str]]:
        if not text:
            return None
        import re

        pattern = r"https?://[^\s]+"
        matches = re.findall(pattern, text)
        return matches or None

    def _extract_urls_from_exception(self, exc: BaseException) -> Optional[List[str]]:
        seen: set[int] = set()
        urls: List[str] = []
        stack = [exc]

        while stack:
            current = stack.pop()
            if id(current) in seen:
                continue
            seen.add(id(current))

            text_urls = self._extract_urls(str(current))
            if text_urls:
                urls.extend(text_urls)

            response = getattr(current, "response", None)
            if response is not None:
                headers = getattr(response, "headers", None)
                if headers:
                    for header_key in ("WWW-Authenticate", "Location", "Link"):
                        header_value = None
                        try:
                            header_value = headers.get(header_key)
                        except Exception:
                            header_value = None
                        if header_value:
                            header_urls = self._extract_urls(str(header_value))
                            if header_urls:
                                urls.extend(header_urls)
                    # Fallback: inspect all header values cautiously
                    try:
                        header_items = list(headers.items())  # type: ignore[attr-defined]
                    except Exception:
                        header_items = []
                    for _, value in header_items:
                        header_urls = self._extract_urls(str(value))
                        if header_urls:
                            urls.extend(header_urls)

            for attr in ("__cause__", "__context__"):
                nested = getattr(current, attr, None)
                if isinstance(nested, BaseException):
                    stack.append(nested)

            if hasattr(current, "exceptions"):
                nested_list = getattr(current, "exceptions")
                if isinstance(nested_list, list):
                    for nested_exc in nested_list:
                        if isinstance(nested_exc, BaseException):
                            stack.append(nested_exc)

        if not urls:
            return None

        deduped = []
        seen_urls = set()
        for url in urls:
            if url not in seen_urls:
                deduped.append(url)
                seen_urls.add(url)
        return deduped

    def _parse_scopes(self, raw: Any) -> List[str]:
        if raw is None:
            return []
        if isinstance(raw, list):
            scopes = [str(item).strip() for item in raw if str(item).strip()]
            return sorted(set(scopes))
        if isinstance(raw, str):
            separators = [",", " "]
            for sep in separators:
                raw = raw.replace(sep, " ")
            scopes = [part.strip() for part in raw.split(" ") if part.strip()]
            return sorted(set(scopes))
        raise ValueError("scopes must be provided as a string or list of strings")

    def _parse_optional_params(self, raw: Any) -> Dict[str, str]:
        if raw is None:
            return {}
        if isinstance(raw, dict):
            result: Dict[str, str] = {}
            for key, value in raw.items():
                if value is None:
                    continue
                result[str(key)] = str(value)
            return result
        if isinstance(raw, str):
            raw = raw.strip()
            if not raw:
                return {}
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Failed to parse oauth_optional_params JSON: {exc}") from exc
            if not isinstance(parsed, dict):
                raise ValueError("oauth_optional_params JSON must decode to an object")
            return self._parse_optional_params(parsed)
        raise ValueError("oauth_optional_params must be provided as an object or JSON string")

    def _store_oauth_settings(self, environment: str, updates: Dict[str, Any]) -> None:
        merged = self._load_stored_oauth_settings(environment) or {}
        for key, value in updates.items():
            if key == "scopes" and isinstance(value, list):
                merged[key] = sorted(set(value))
            elif key == "oauth_optional_params" and isinstance(value, dict):
                merged[key] = value
            else:
                merged[key] = value

        serialized = json.dumps(merged)
        self._credential_service.store_credential(
            self.user_id,
            f"{OAUTH_CONFIG_CREDENTIAL_PREFIX}{environment}",
            self._server_name,
            serialized,
        )

    def _load_stored_oauth_settings(self, environment: str) -> Optional[Dict[str, Any]]:
        stored = self._credential_service.get_credential(
            self.user_id,
            f"{OAUTH_CONFIG_CREDENTIAL_PREFIX}{environment}",
            self._server_name,
        )
        if not stored:
            return None
        try:
            data = json.loads(stored)
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            self.logger.warning("Failed to parse stored Square OAuth settings; ignoring corrupted data")
        return None

    def _get_oauth_settings(self, environment: str) -> Dict[str, Any]:
        env = environment.lower()
        base = {
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
            "redirect_uri": self._config.redirect_uri,
            "scopes": list(self._config.scopes or []),
            "oauth_optional_params": dict(self._config.oauth_optional_params or {}),
        }
        stored = self._load_stored_oauth_settings(env)
        if stored:
            for key, value in stored.items():
                if value in (None, ""):
                    continue
                if key == "scopes" and isinstance(value, list):
                    base[key] = [str(item).strip() for item in value if str(item).strip()]
                elif key == "oauth_optional_params" and isinstance(value, dict):
                    base[key] = {str(k): str(v) for k, v in value.items() if v is not None}
                else:
                    base[key] = value
        base["scopes"] = [scope for scope in base.get("scopes", []) if scope]
        return base

    def _build_authorization_context(self, environment: Optional[str] = None) -> Dict[str, Any]:
        env = (environment or self._config.environment or "production").lower()
        if env not in OAUTH_AUTHORIZE_URLS:
            raise ValueError(
                f"Unsupported Square OAuth environment '{env}'. Use 'production' or 'sandbox'."
            )

        settings = self._get_oauth_settings(env)
        client_id = settings.get("client_id")
        redirect_uri = settings.get("redirect_uri")
        scopes = settings.get("scopes", [])

        if not client_id or not redirect_uri or not scopes:
            raise ValueError(
                "Square OAuth requires client_id, redirect_uri, and at least one scope. "
                "Call the configure_oauth operation with these values before requesting an authorization URL."
            )

        optional_params = settings.get("oauth_optional_params") or {}

        state = uuid.uuid4().hex
        try:
            self._credential_service.store_credential(
                self.user_id,
                f"{OAUTH_STATE_CREDENTIAL_PREFIX}{env}",
                self._server_name,
                state,
            )
        except Exception:
            self.logger.debug("Unable to persist Square OAuth state; proceeding without storage")

        query_params = {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "scope": " ".join(scopes),
            "response_type": "code",
            "state": state,
        }
        for key, value in (optional_params or {}).items():
            if value is not None:
                query_params[key] = value

        authorization_url = f"{OAUTH_AUTHORIZE_URLS[env]}?{urlencode(query_params)}"

        sanitized_settings = {k: v for k, v in settings.items() if k != "client_secret"}

        return {
            "authorization_url": authorization_url,
            "state": state,
            "scopes": scopes,
            "environment": env,
            "settings": sanitized_settings,
        }


__all__ = ["SquareTool", "SquareToolConfig"]
