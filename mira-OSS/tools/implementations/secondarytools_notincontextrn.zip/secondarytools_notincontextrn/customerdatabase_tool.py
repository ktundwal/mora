"""
Customer management tool with database support.

This tool provides customer directory management capabilities including loading,
saving, searching, and location-based customer finding functionality. It uses a
SQLite database for persistent storage while maintaining compatibility with the
original JSON-based storage.
"""

import logging
import time
import json
from typing import Dict, List, Any, Optional
from uuid import uuid4

from pydantic import BaseModel, Field

from tools.repo import Tool
from tools.registry import registry
from utils.timezone_utils import utc_now, format_utc_iso

# Define configuration class for CustomerDatabaseTool
class CustomerdatabaseToolConfig(BaseModel):
    """Configuration for the customerdatabase_tool."""
    enabled: bool = Field(default=True, description="Whether this tool is enabled by default")
    # Add any other configuration fields specific to this tool

# Register with registry
registry.register("customerdatabase_tool", CustomerdatabaseToolConfig)




class CustomerDatabaseTool(Tool):
    """
    Tool for managing a customer directory with search capabilities using SQLite database.
    
    Features:
    1. Customer Directory Management:
       - Load and save customer data to/from database
       - Maintain a local cache of customer information
       - Rebuild directory from external sources

    2. Customer Search:
       - Find customers by name, email, phone, address
       - Automatically categorize search queries
       - Location-based customer searching
    """

    name = "customerdatabase_tool"
    anthropic_schema = {
        "name": "customerdatabase_tool",
        "description": "Accesses the customer directory to search, retrieve, and rebuild customer records stored in the local database.",
        "input_schema": {
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": [
                            "search_customers",
                            "find_closest_customers",
                            "rebuild_directory",
                            "get_customer"
                        ],
                        "description": "Customer directory operation to perform"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search text for customer lookup operations. Supports name, email, phone, or address queries"
                    },
                    "category": {
                        "type": "string",
                        "enum": [
                            "name",
                            "given_name",
                            "family_name",
                            "email",
                            "phone",
                            "address",
                            "any"
                        ],
                        "description": "Optional hint to focus the search on a specific attribute"
                    },
                    "lat": {
                        "type": "number",
                        "minimum": -90,
                        "maximum": 90,
                        "description": "Latitude in decimal degrees for proximity searches"
                    },
                    "lng": {
                        "type": "number",
                        "minimum": -180,
                        "maximum": 180,
                        "description": "Longitude in decimal degrees for proximity searches"
                    },
                    "limit": {
                        "type": "integer",
                        "minimum": 1,
                        "description": "Maximum number of customers to return when searching by location (default 1)"
                    },
                    "max_distance": {
                        "type": "number",
                        "minimum": 0,
                        "description": "Maximum distance in meters when searching for nearby customers"
                    },
                    "exclude_customer_id": {
                        "type": "string",
                        "description": "Customer ID to omit from proximity results"
                    },
                    "source": {
                        "type": "string",
                        "description": "Data source to use when rebuilding the directory (default 'square')"
                    },
                    "customer_id": {
                        "type": "string",
                        "description": "Unique identifier of the customer to retrieve"
                    }
                },
                "required": ["operation"]
            }
        }

    simple_description = """Manages a comprehensive customer directory using database storage with robust search and location-based capabilities. This tool allows you to retrieve details about existing customers. DO NOT use this tool if you believe you need to create a new customer or edit an existing customer's details. If you need to create a new customer/edit details use squareviahttp_tool instead."""
    
    implementation_details = """
This tool maintains a SQLite database for customer data with support for importing from external systems (currently Square via HTTP API). It provides efficient searching and retrieving of customer data through multiple operations:

1. search_customers: Find customers by various identifiers including name, email, phone number, or address. 
   - Requires 'query' parameter with your search term
   - Optional 'category' parameter to specify search type: 'name', 'given_name', 'family_name', 'email', 'phone', 'address', or 'any' (default)
   - Returns matching customer records with contact details

2. find_closest_customers: Locate nearby customers using geographical coordinates.
   - Requires 'lat' and 'lng' parameters (latitude/longitude)
   - Optional 'limit' parameter to specify maximum number of results (default: 1)
   - Optional 'max_distance' parameter to set maximum distance in meters
   - Optional 'exclude_customer_id' to omit a specific customer
   - Returns customers sorted by proximity with distance information

3. get_customer: Retrieve a specific customer record by ID.
   - Requires 'customer_id' parameter
   - Returns complete customer information

4. rebuild_directory: Refresh the customer database from external systems.
   - Optional 'source' parameter (currently only supports 'square')
   - Uses the squareviahttp_tool to retrieve customer data directly from Square API
   - Automatically handles pagination to retrieve all customers
   - Returns status information about the rebuild operation"""

    description = simple_description + implementation_details

    def __init__(self):
        """Initialize the Customer tool."""
        super().__init__()
        self.logger = logging.getLogger(__name__)
        
        # Defer user-context-dependent operations to first use
        self._db_client = None
        self._customer_cache = {}
        self._cache_timestamp = 0
        self._cache_loaded = False
        self._schema_initialized = False

        self.table_name = "customers"
        self._json_columns = ["raw_data"]
        self._address_fields = [
            "address_line1",
            "address_line2",
            "city",
            "state",
            "postal_code",
            "country"
        ]

    @property
    def db_client(self):
        """Lazy-load per-user SQLite client and ensure schema."""
        if self._db_client is None:
            # The shared UserDataManager already scopes this client per user
            self._db_client = self.db.db_client

        if not self._schema_initialized:
            self._ensure_schema()
            self._schema_initialized = True

        return self._db_client

    def _ensure_schema(self) -> None:
        """Create or upgrade the customers table inside the per-user database."""
        client = self._db_client
        if not client.table_exists(self.table_name):
            client.execute_query(
                f"""
                CREATE TABLE IF NOT EXISTS {self.table_name} (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    display_name TEXT,
                    given_name TEXT,
                    family_name TEXT,
                    email TEXT,
                    phone TEXT,
                    company TEXT,
                    notes TEXT,
                    address_line1 TEXT,
                    address_line2 TEXT,
                    city TEXT,
                    state TEXT,
                    postal_code TEXT,
                    country TEXT,
                    latitude REAL,
                    longitude REAL,
                    geocoded_at TEXT,
                    source TEXT,
                    raw_data TEXT,
                    square_created_at TEXT,
                    square_updated_at TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )

            client.execute_query(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table_name}_user ON {self.table_name}(user_id)"
            )
            client.execute_query(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table_name}_email ON {self.table_name}(user_id, email)"
            )
            return

        # Add any missing columns that may be required for the modernized schema
        schema_info = client.get_table_schema(self.table_name)
        existing_columns = {column_info["name"].lower() for column_info in schema_info}

        optional_columns = {
            "display_name": "display_name TEXT",
            "given_name": "given_name TEXT",
            "family_name": "family_name TEXT",
            "email": "email TEXT",
            "phone": "phone TEXT",
            "company": "company TEXT",
            "notes": "notes TEXT",
            "address_line1": "address_line1 TEXT",
            "address_line2": "address_line2 TEXT",
            "city": "city TEXT",
            "state": "state TEXT",
            "postal_code": "postal_code TEXT",
            "country": "country TEXT",
            "latitude": "latitude REAL",
            "longitude": "longitude REAL",
            "geocoded_at": "geocoded_at TEXT",
            "source": "source TEXT",
            "raw_data": "raw_data TEXT",
            "square_created_at": "square_created_at TEXT",
            "square_updated_at": "square_updated_at TEXT"
        }

        for column_name, column_definition in optional_columns.items():
            if column_name not in existing_columns:
                client.execute_query(
                    f"ALTER TABLE {self.table_name} ADD COLUMN {column_definition}"
                )

    @staticmethod
    def _clean_str(value: Optional[Any]) -> Optional[str]:
        if value is None:
            return None
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return str(value)

    @staticmethod
    def _to_float(value: Optional[Any]) -> Optional[float]:
        if value is None or value == "":
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _transform_customer_record(self, raw_customer: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize Square customer payload into our storage schema."""
        address = raw_customer.get("address") or {}
        phone = None
        phone_numbers = raw_customer.get("phone_numbers") or raw_customer.get("phone_number")
        if isinstance(phone_numbers, list) and phone_numbers:
            phone = phone_numbers[0].get("phone_number") or phone_numbers[0].get("number")
        elif isinstance(phone_numbers, str):
            phone = phone_numbers

        given_name = self._clean_str(raw_customer.get("given_name"))
        family_name = self._clean_str(raw_customer.get("family_name"))
        company = self._clean_str(raw_customer.get("company_name"))
        nickname = self._clean_str(raw_customer.get("nickname"))

        display_name_parts = [part for part in [given_name, family_name] if part]
        display_name = " ".join(display_name_parts).strip()
        if not display_name:
            display_name = nickname or company or self._clean_str(raw_customer.get("email_address"))
        if not display_name:
            display_name = "Unknown Customer"

        def get_address_field(*candidates: str) -> Optional[str]:
            for candidate in candidates:
                value = address.get(candidate)
                if value:
                    return self._clean_str(value)
            return None

        latitude = self._to_float(
            raw_customer.get("latitude")
            or (raw_customer.get("coordinates") or {}).get("latitude")
        )
        longitude = self._to_float(
            raw_customer.get("longitude")
            or (raw_customer.get("coordinates") or {}).get("longitude")
        )

        customer_id = self._clean_str(raw_customer.get("id"))
        if not customer_id:
            customer_id = f"local-{uuid4().hex}"

        record = {
            "id": customer_id,
            "display_name": display_name,
            "given_name": given_name,
            "family_name": family_name,
            "email": self._clean_str(raw_customer.get("email_address")),
            "phone": self._clean_str(phone),
            "company": company,
            "notes": self._clean_str(raw_customer.get("note")),
            "address_line1": get_address_field("address_line1", "address_line_1", "line1"),
            "address_line2": get_address_field("address_line2", "address_line_2", "line2"),
            "city": get_address_field("city", "locality"),
            "state": get_address_field("state", "administrative_district_level_1"),
            "postal_code": get_address_field("postal_code", "postalCode"),
            "country": get_address_field("country", "country_code"),
            "latitude": latitude,
            "longitude": longitude,
            "geocoded_at": self._clean_str(raw_customer.get("geocoded_at")),
            "source": "square",
            "raw_data": raw_customer,
            "square_created_at": self._clean_str(raw_customer.get("created_at")),
            "square_updated_at": self._clean_str(raw_customer.get("updated_at"))
        }

        return record

    def _insert_customer(self, record: Dict[str, Any]) -> None:
        payload = record.copy()
        json_columns = self._json_columns if "raw_data" in payload else None
        self.db_client.json_insert(
            self.table_name,
            payload,
            json_columns=json_columns
        )

    def _update_customer(self, customer_id: str, record: Dict[str, Any]) -> int:
        payload = record.copy()
        payload.pop("id", None)
        json_columns = self._json_columns if "raw_data" in payload else None
        return self.db_client.json_update(
            self.table_name,
            payload,
            where_clause="id = :id",
            where_params={"id": customer_id},
            json_columns=json_columns
        )

    def _count_customers(self) -> int:
        rows = self.db_client.execute_query(
            f"SELECT COUNT(*) as count FROM {self.table_name} WHERE user_id = :user_id",
            {"user_id": self.db_client.user_id}
        )
        return rows[0]["count"] if rows else 0

    def _load_customer_cache(self) -> Dict[str, Any]:
        """
        Load customers from database into memory cache for faster access.

        Returns:
            Dict with customers indexed by ID and metadata
        """
        # If cache is already loaded and fresh, return it
        now = time.time()
        if self._cache_loaded and now - self._cache_timestamp < 300:  # 5 minutes
            return self._customer_cache
            
        # Load customers from database
        customers = self.db_client.json_select(
            self.table_name,
            order_by='display_name',
            json_columns=self._json_columns
        )
            
        # Build cache
        cache = {}
        for customer in customers:
            cache[customer['id']] = customer
            
        # Update cache
        self._customer_cache = cache
        self._cache_timestamp = now
        self._cache_loaded = True
        
        self.logger.info(f"Loaded {len(cache)} customers into cache")
        return cache

    def _invalidate_cache(self):
        """Invalidate the customer cache, forcing reload on next access."""
        self._cache_loaded = False
        self._customer_cache = {}
        self._cache_timestamp = 0

    def rebuild_directory(self, source="square") -> Dict[str, Any]:
        """
        Rebuild the customer directory from an external source.

        Args:
            source: Source system to rebuild the directory from (default: square)

        Returns:
            Dict with status and results
        """
        if source.lower() != "square":
            self.logger.error(f"Unsupported rebuild source '{source}' in customerdatabase_tool")
            raise ValueError("Unsupported source for rebuild: only 'square' is currently supported")

        try:
            try:
                from tools.implementations.squareapi_tool import SquareApiTool
            except ImportError as import_err:
                self.logger.error(f"Square module import failed: {import_err}")
                raise ValueError(f"Cannot rebuild from Square: module import failed: {import_err}")

            square_tool = SquareApiTool()
            response = square_tool.run(operation="list_customers") or {}
            customers = response.get("data", {}).get("customers", [])
            total_fetched = len(customers)

            db = self.db_client
            existing_rows = db.execute_query(
                f"SELECT id FROM {self.table_name} WHERE user_id = :user_id",
                {"user_id": db.user_id}
            )
            existing_ids = {row["id"] for row in existing_rows if row.get("id")}

            processed_ids = set()
            new_ids = set()
            inserted = 0
            updated = 0

            for raw_customer in customers:
                record = self._transform_customer_record(raw_customer)
                customer_id = record.get("id")
                if not customer_id:
                    continue

                processed_ids.add(customer_id)

                if customer_id in existing_ids:
                    # Update existing customer
                    rows_updated = self._update_customer(customer_id, record)
                    if rows_updated:
                        updated += 1
                else:
                    self._insert_customer(record)
                    inserted += 1
                    new_ids.add(customer_id)

            # Remove customers not present in the latest payload
            deleted = 0
            stale_ids = existing_ids - processed_ids
            for stale_id in stale_ids:
                deleted += db.json_delete(self.table_name, "id = :id", {"id": stale_id})

            # Geocode any customers missing coordinates that were just created
            if new_ids:
                self._geocode_customers(list(new_ids))

            self._invalidate_cache()

            total_rows = db.execute_query(
                f"SELECT COUNT(*) as count FROM {self.table_name} WHERE user_id = :user_id",
                {"user_id": db.user_id}
            )
            final_count = total_rows[0]["count"] if total_rows else 0

            message = (
                f"Customer directory synchronized with Square. "
                f"Fetched {total_fetched}, inserted {inserted}, updated {updated}, deleted {deleted}."
            )

            return {
                "success": True,
                "customer_count": final_count,
                "fetched_customers": total_fetched,
                "new_customers": inserted,
                "updated_customers": updated,
                "deleted_customers": deleted,
                "message": message
            }

        except Exception as exc:
            self.logger.error(f"Error rebuilding customer directory: {exc}")
            return {
                "success": False,
                "error": str(exc),
                "message": "Failed to rebuild customer directory"
            }

    def _geocode_customers(self, customer_ids: List[str]) -> Dict[str, bool]:
        """
        Geocode multiple customers using Maps API.

        Args:
            customer_ids: List of customer IDs to geocode

        Returns:
            Dict mapping customer IDs to success status
        """
        if not customer_ids:
            return {}

        try:
            from tools.implementations.maps_tool import MapsTool

            maps_tool = MapsTool()
            results: Dict[str, bool] = {}
            updated_any = False

            for customer_id in customer_ids:
                records = self.db_client.json_select(
                    self.table_name,
                    where_clause="id = :id",
                    where_params={"id": customer_id},
                    limit=1,
                    json_columns=self._json_columns
                )

                if not records:
                    results[customer_id] = False
                    continue

                record = records[0]

                # Skip if we already have coordinates
                if record.get("latitude") is not None and record.get("longitude") is not None:
                    results[customer_id] = True
                    continue

                address_str = self._format_address(record)
                if not address_str:
                    results[customer_id] = False
                    continue

                try:
                    time.sleep(0.5)  # simple rate limiting safeguard
                    geocode_result = maps_tool.run(
                        operation="geocode",
                        query=address_str
                    )

                    location = (
                        (geocode_result or {})
                        .get("results", [{}])[0]
                        .get("location", {})
                    )

                    latitude = self._to_float(location.get("lat"))
                    longitude = self._to_float(location.get("lng"))

                    if latitude is None or longitude is None:
                        results[customer_id] = False
                        continue

                    self.db_client.json_update(
                        self.table_name,
                        data={
                            "latitude": latitude,
                            "longitude": longitude,
                            "geocoded_at": format_utc_iso(utc_now())
                        },
                        where_clause="id = :id",
                        where_params={"id": customer_id}
                    )

                    results[customer_id] = True
                    updated_any = True
                    self.logger.info(f"Successfully geocoded customer {customer_id}")

                except Exception as geocode_exc:
                    self.logger.error(f"Error geocoding customer {customer_id}: {geocode_exc}")
                    results[customer_id] = False

            if updated_any:
                self._invalidate_cache()

            return results

        except Exception as exc:
            self.logger.error(f"Error in geocoding process: {exc}")
            return {customer_id: False for customer_id in customer_ids}

    def _format_address(self, customer_record: Dict[str, Any]) -> str:
        parts = [self._clean_str(customer_record.get(field)) for field in self._address_fields]
        return " ".join(part for part in parts if part).strip()

    def _search_customers(
        self, query: str, category: str = None
    ) -> List[Dict[str, Any]]:
        """
        Search for customers in the database.

        Args:
            query: The search term
            category: The search category (name, given_name, family_name, email, phone, address, any).
                     If not provided, the LLM will determine the appropriate category.

        Returns:
            List of matching customer records
        """
        self.logger.info(f"Searching customer database for: '{query}' with category: {category}")

        search_term = (query or "").strip()
        if not search_term:
            return []

        normalized_category = (category or "any").lower()

        # For exact ID matching
        if normalized_category == "id":
            customers = self.db_client.json_select(
                self.table_name,
                where_clause='id = :id',
                where_params={'id': search_term},
                limit=1,
                json_columns=self._json_columns
            )
            return customers

        lower_query = f"%{search_term.lower()}%"
        phone_query = f"%{search_term}%"
        params = {
            'lower_query': lower_query,
            'phone_query': phone_query
        }

        where_conditions: List[str] = []

        if normalized_category == "name":
            where_conditions.append("LOWER(display_name) LIKE :lower_query")
        elif normalized_category == "given_name":
            where_conditions.append("LOWER(given_name) LIKE :lower_query")
        elif normalized_category == "family_name":
            where_conditions.append("LOWER(family_name) LIKE :lower_query")
        elif normalized_category == "email":
            where_conditions.append("LOWER(email) LIKE :lower_query")
        elif normalized_category == "phone":
            where_conditions.append("phone LIKE :phone_query")
        elif normalized_category == "company":
            where_conditions.append("LOWER(company) LIKE :lower_query")
        elif normalized_category == "address":
            address_clauses = [f"LOWER({field}) LIKE :lower_query" for field in self._address_fields]
            where_conditions.append(f"({' OR '.join(address_clauses)})")
        else:  # Default to searching across all relevant fields
            composite_conditions = [
                "LOWER(display_name) LIKE :lower_query",
                "LOWER(given_name) LIKE :lower_query",
                "LOWER(family_name) LIKE :lower_query",
                "LOWER(email) LIKE :lower_query",
                "phone LIKE :phone_query",
                "LOWER(company) LIKE :lower_query"
            ]
            composite_conditions.extend([f"LOWER({field}) LIKE :lower_query" for field in self._address_fields])
            where_conditions.append(f"({' OR '.join(composite_conditions)})")

        where_clause = " OR ".join(where_conditions) if where_conditions else "1=1"
        results = self.db_client.json_select(
            self.table_name,
            where_clause=where_clause,
            where_params=params,
            order_by='display_name',
            json_columns=self._json_columns
        )

        self.logger.info(f"Database search found {len(results)} matching customers")
        return results

    def search_customers(
        self, query: str, category: str = None
    ) -> Dict[str, Any]:
        """
        Search for customers in the database with automatic rebuild if needed.

        Args:
            query: The search term
            category: Optional category override (name, email, phone, address, any)
                     If not provided, Claude will intelligently determine the category.
                     
                     Valid categories:
                     - "name": Full name search (first and last name together)
                     - "given_name": First/given name only search
                     - "family_name": Last/family name only search
                     - "address": Address search (any address component)
                     - "phone": Phone number search 
                     - "email": Email address search
                     - "any": Search across all fields (default if not specified)

        Returns:
            Dict with 'search_type' and 'customers' list containing matching records

        Raises:
            ValueError: If no matches found after rebuild
        """
        # Check if database is empty
        customer_count = self._count_customers()
            
        if customer_count == 0:
            self.logger.info(
                "Customer database empty. Building it now..."
            )
            result = self.rebuild_directory()
            if not result.get("success", False):
                self.logger.error("Failed to build initial customer directory")
                self.logger.error("Failed to initialize customer directory in customerdatabase_tool")
                raise ValueError("Failed to initialize customer directory")

        # Determine search type for the response
        search_type = "Search"
        if category == "name":
            search_type = "Full Name Search"
        elif category == "given_name":
            search_type = "Given Name Search"
        elif category == "family_name":
            search_type = "Family Name Search"
        elif category == "address":
            search_type = "Address Search"
        elif category == "phone":
            search_type = "Phone Number Search"
        elif category == "email":
            search_type = "Email Address Search"
        elif category == "any" or category is None:
            search_type = "Multi-field Search"
            category = "any"  # Default to any if not specified

        self.logger.info(f"Searching with category: {category}")

        # Now search using the database
        results = self._search_customers(query, category)

        # If no results, rebuild directory and try again
        if not results:
            self.logger.info(
                "No results found in database. Rebuilding customer directory..."
            )
            result = self.rebuild_directory()

            if result.get("success", False):
                self.logger.info("Directory rebuilt, searching again...")
                results = self._search_customers(query, category)
            else:
                self.logger.error("Failed to rebuild customer directory")

        # If still no results, raise error
        if not results:
            self.logger.error(f"No customers found matching '{query}' in category '{category}' in customerdatabase_tool")
            raise ValueError(f"No customers found matching '{query}' in category '{category}'")

        return {
            "search_type": search_type,
            "customers": results
        }

    def find_closest_customers(
        self, lat: float, lng: float, limit: int = 1, max_distance: Optional[float] = None, 
        exclude_customer_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Find the closest customers to a specific location.
        
        Args:
            lat: Latitude in decimal degrees
            lng: Longitude in decimal degrees
            limit: Maximum number of customers to return, sorted by proximity (default: 1)
            max_distance: Optional maximum distance in meters
            exclude_customer_id: Optional customer ID to exclude from results (e.g., to exclude the reference customer)
            
        Returns:
            Dict with 'customers' list containing nearby customers, sorted by distance.
            Each customer record includes a 'distance_meters' field.
            
        Raises:
            ValueError: If no customers with coordinates found
        """
        self.logger.info(f"Searching for customers near coordinates: {lat}, {lng}")
        
        # Check if database is empty
        customer_count = self._count_customers()
            
        if customer_count == 0:
            self.logger.info("Customer database empty. Building it now...")
            result = self.rebuild_directory()
            if not result.get("success", False):
                self.logger.error("Failed to build initial customer directory")
                self.logger.error("Failed to initialize customer directory in customerdatabase_tool")
                raise ValueError("Failed to initialize customer directory")
        
        try:
            # Import maps_tool to use distance calculation
            from tools.implementations.maps_tool import MapsTool
            maps_tool = MapsTool()
            
            # Query customers with geocoding data
            where_clause = "latitude IS NOT NULL AND longitude IS NOT NULL"
            where_params = {}
            
            # Exclude specific customer if requested
            if exclude_customer_id:
                where_clause += " AND id != :exclude_id"
                where_params['exclude_id'] = exclude_customer_id
                
            customers = self.db_client.json_select(
                self.table_name,
                where_clause=where_clause,
                where_params=where_params,
                json_columns=self._json_columns
            )
            
            results_with_distance = []
            
            # Calculate distances for each customer
            for customer in customers:
                try:
                    lat2 = self._to_float(customer.get('latitude'))
                    lng2 = self._to_float(customer.get('longitude'))
                    if lat2 is None or lng2 is None:
                        continue

                    # Calculate distance using maps_tool
                    distance_result = maps_tool.run(
                        operation="calculate_distance",
                        lat1=lat,
                        lng1=lng,
                        lat2=lat2,
                        lng2=lng2
                    )

                    distance = distance_result.get("distance_meters")

                    # Skip if beyond max distance
                    if max_distance is not None and distance is not None and distance > max_distance:
                        continue
                        
                    # Add distance to customer dict
                    customer_dict = customer.copy()
                    customer_dict["distance_meters"] = distance
                    
                    results_with_distance.append(customer_dict)
                except Exception as e:
                    self.logger.error(f"Error calculating distance for customer {customer['id']}: {e}")
                    continue
            
            # Sort results by distance and apply limit
            results_with_distance.sort(key=lambda item: item.get("distance_meters") or float('inf'))
            if limit:
                results_with_distance = results_with_distance[:limit]
            
            # Limit the number of results
            results_with_distance = results_with_distance[:limit] if limit else results_with_distance
            
            # If no results with coordinates, try rebuilding the directory
            if not results_with_distance:
                # Don't try to rebuild and search again - that causes infinite recursion
                # Just tell the user there are no customers with coordinates
                if max_distance is not None:
                    msg = f"No customers found within {max_distance} meters of the specified location"
                else:
                    msg = "No customers found with coordinates within the specified range"
                
                self.logger.info(msg)
                self.logger.error(f"No customers with coordinates found in customerdatabase_tool: {msg}")
                raise ValueError(msg)
            
            self.logger.info(f"Found {len(results_with_distance)} nearby customers")
            return {"customers": results_with_distance}
            
        except Exception as e:
            self.logger.error(f"Error finding closest customers: {e}")
            self.logger.error(f"Error finding closest customers in customerdatabase_tool: {e}")
            raise ValueError(f"Error finding closest customers: {e}")

    def get_customer(self, customer_id: str) -> Dict[str, Any]:
        """
        Get a customer by ID from the database.
        
        Args:
            customer_id: The ID of the customer to retrieve
            
        Returns:
            Dict with customer information
            
        Raises:
            ValueError: If customer is not found
        """
        records = self.db_client.json_select(
            self.table_name,
            where_clause='id = :id',
            where_params={'id': customer_id},
            limit=1,
            json_columns=self._json_columns
        )

        if not records:
            self.logger.error(f"Customer with ID '{customer_id}' not found in customerdatabase_tool")
            raise ValueError(f"Customer with ID '{customer_id}' not found")
            
        return {"customer": records[0]}

    def run(self, operation: str, **kwargs) -> Dict[str, Any]:
        """
        Execute a customer directory operation.

        Args:
            operation: Operation to perform (see below for valid operations)
            **kwargs: Parameters for the specific operation

        Returns:
            Response data for the operation

        Raises:
            ValueError: If operation fails or parameters are invalid

        Valid Operations:

        1. search_customers: Search for customers in the local directory
           - Required: query (search term - name, email, phone, address)
           - Optional: category (name, given_name, family_name, email, phone, address, any)
           - Returns: Dict with search_type and list of matching customer records

        2. find_closest_customers: Find customers closest to specified coordinates
           - Required: latitude, longitude
           - Optional: limit (default: 1), max_distance (in meters)
           - Returns: List of customer records with distance information

        3. rebuild_directory: Rebuild the customer directory from external source
           - Optional: source (default: "square")
           - Returns: Status of rebuild operation

        4. get_customer: Get a customer by ID
           - Required: customer_id
           - Returns: Customer record
        """
        try:
            params = dict(kwargs)

            # Support legacy callers that pass a JSON string inside a kwargs field
            raw_kwargs = params.pop("kwargs", None)
            if raw_kwargs is not None:
                if isinstance(raw_kwargs, str):
                    try:
                        parsed = json.loads(raw_kwargs)
                        self.logger.debug(f"Parsed kwargs JSON: {parsed}")
                        params.update(parsed)
                    except json.JSONDecodeError as e:
                        self.logger.error(f"Invalid JSON in kwargs for customerdatabase_tool: {e}")
                        raise ValueError(f"Invalid JSON in kwargs: {e}")
                elif isinstance(raw_kwargs, dict):
                    params.update(raw_kwargs)
                else:
                    self.logger.error("Unsupported kwargs format provided to customerdatabase_tool")
                    raise ValueError("kwargs field must be a JSON string or object when provided")
            
            # Directory Search Operations
            if operation == "search_customers":
                if "query" not in params:
                    self.logger.error("Missing query parameter for search_customers operation in customerdatabase_tool")
                    raise ValueError("query parameter is required for search_customers operation")
                
                # Reject empty queries to prevent returning all records and token explosions
                if params["query"].strip() == "":
                    self.logger.error("Empty query provided for search_customers operation in customerdatabase_tool")
                    raise ValueError("Empty query not allowed. Please provide a specific search term or use find_closest_customers operation for location-based search.")
                    
                return self.search_customers(
                    query=params["query"], category=params.get("category")
                )

            elif operation == "find_closest_customers":
                # Check for required parameters
                lat_param = params.get("lat") or params.get("latitude")
                lng_param = params.get("lng") or params.get("longitude")
                
                if not lat_param or not lng_param:
                    self.logger.error("Missing latitude/longitude parameters for find_closest_customers operation in customerdatabase_tool")
                    raise ValueError("latitude/lat and longitude/lng parameters are required for find_closest_customers operation")
                
                try:
                    lat = float(lat_param)
                    lng = float(lng_param)
                    
                    # Optional parameters
                    limit = int(params["limit"]) if "limit" in params else 1
                    max_distance = float(params["max_distance"]) if "max_distance" in params else None
                    exclude_customer_id = params.get("exclude_customer_id")
                    
                    return self.find_closest_customers(
                        lat=lat,
                        lng=lng,
                        limit=limit,
                        max_distance=max_distance,
                        exclude_customer_id=exclude_customer_id
                    )
                except ValueError:
                    self.logger.error("Invalid numeric parameters for find_closest_customers operation in customerdatabase_tool")
                    raise ValueError("lat, lng, limit, and max_distance must be valid numbers")

            elif operation == "rebuild_directory":
                source = params.get("source", "square")
                return self.rebuild_directory(source=source)
                
            elif operation == "get_customer":
                if "customer_id" not in params:
                    self.logger.error("Missing customer_id parameter for get_customer operation in customerdatabase_tool")
                    raise ValueError("customer_id parameter is required for get_customer operation")
                return self.get_customer(customer_id=params["customer_id"])

            else:
                self.logger.error(f"Unknown operation '{operation}' in customerdatabase_tool")
                raise ValueError(
                    f"Unknown operation: {operation}. Valid operations are: "
                    "search_customers, find_closest_customers, rebuild_directory, get_customer"
                )
        except Exception as e:
            self.logger.error(f"Error executing customerdatabase_tool operation '{operation}': {e}")
            raise

